class Routes {
  static const String SPLASH = "/";
  static const String HOME = "/home/homeScreen";
  static const String LOGIN = "/login/loginScreen";
  static const String OTP = "/login/otpValidationScreen";
  static const String TAB = '/home/tabScreen';
}
